/* Service Worker — حضور و غیاب (offline-first) */
const VERSION = 'hazor-v3';
const CORE = `${VERSION}-core`;
const RUNTIME = `${VERSION}-runtime`;

/* App shell: everything needed to boot the app offline. */
const PRECACHE_URLS = [
  '/',
  '/manifest.json',
  '/icons/icon-96.png',
  '/icons/icon-192.png',
  '/icons/icon-512.png',
  '/icons/icon-512-maskable.png',
  '/icons/apple-touch-icon.png',
  '/fonts/Vazirmatn-Regular.woff2',
  '/fonts/Vazirmatn-Medium.woff2',
  '/fonts/Vazirmatn-Bold.woff2',
  '/fonts/Vazirmatn-Black.woff2',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    (async () => {
      const cache = await caches.open(CORE);
      await Promise.allSettled(PRECACHE_URLS.map((u) => cache.add(new Request(u, { cache: 'reload' }))));
      await self.skipWaiting();
    })()
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    (async () => {
      const keys = await caches.keys();
      await Promise.all(
        keys.filter((k) => !k.startsWith(VERSION)).map((k) => caches.delete(k))
      );
      await self.clients.claim();
    })()
  );
});

self.addEventListener('message', (event) => {
  if (event.data === 'SKIP_WAITING') self.skipWaiting();
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;

  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;

  /* Never touch dev/hot-reload machinery. */
  if (
    url.pathname.startsWith('/_next/webpack-hmr') ||
    url.pathname.startsWith('/_next/static/webpack/') ||
    url.pathname.startsWith('/__nextjs')
  ) {
    return;
  }

  /*
   * Navigations: network-first, fall back to the cached app shell ('/').
   * The app is a single-route client-side app, so '/' is enough to boot.
   */
  if (req.mode === 'navigate') {
    event.respondWith(
      (async () => {
        try {
          const fresh = await fetch(req);
          const cache = await caches.open(RUNTIME);
          cache.put('/', fresh.clone());
          return fresh;
        } catch {
          const runtime = await caches.open(RUNTIME);
          const core = await caches.open(CORE);
          return (
            (await runtime.match('/')) ||
            (await core.match('/')) ||
            new Response('offline', { status: 503, statusText: 'offline' })
          );
        }
      })()
    );
    return;
  }

  /* Truly static, self-versioned files: cache-first. */
  if (
    url.pathname.startsWith('/fonts/') ||
    url.pathname.startsWith('/icons/') ||
    url.pathname === '/manifest.json'
  ) {
    event.respondWith(
      (async () => {
        const core = await caches.open(CORE);
        const hit = await core.match(req);
        if (hit) return hit;
        try {
          const fresh = await fetch(req);
          if (fresh.ok) core.put(req, fresh.clone());
          return fresh;
        } catch {
          return new Response('', { status: 504 });
        }
      })()
    );
    return;
  }

  /*
   * Everything else (/_next chunks, RSC payloads, ...): network-first with
   * cache fallback. Network-first keeps dev hot-reload correct and still
   * works offline once assets have been seen at least once.
   */
  event.respondWith(
    (async () => {
      const cache = await caches.open(RUNTIME);
      try {
        const fresh = await fetch(req);
        if (fresh && fresh.ok) cache.put(req, fresh.clone());
        return fresh;
      } catch {
        const cached = await cache.match(req);
        if (cached) return cached;
        return new Response('', { status: 504 });
      }
    })()
  );
});
